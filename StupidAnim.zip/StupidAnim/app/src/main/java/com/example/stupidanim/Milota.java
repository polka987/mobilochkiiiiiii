package com.example.stupidanim;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.google.android.material.button.MaterialButton;

public class Milota extends AppCompatActivity {
    private ImageView imageView;
    private MaterialButton button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_milota);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left);
        imageView = findViewById(R.id.meowcat);
        button = findViewById(R.id.nazad);
        Animation animation = AnimationUtils.loadAnimation(this, R.anim.anima);
        animation.setFillAfter(true);
        Animation animation1 = AnimationUtils.loadAnimation(this, R.anim.nazad);
        animation1.setFillAfter(true);
        button.startAnimation(animation1);
        imageView.startAnimation(animation);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(Milota.this, MainActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            }
        });
    }
}