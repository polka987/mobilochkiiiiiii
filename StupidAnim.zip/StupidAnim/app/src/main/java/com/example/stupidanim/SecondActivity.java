package com.example.stupidanim;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.google.android.material.button.MaterialButton;

public class SecondActivity extends AppCompatActivity {
    private ImageView imageView;
    private MaterialButton button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.katshehe);
        imageView = findViewById(R.id.anim_id1);
        button = findViewById(R.id.naz);
        Animation animation1 = AnimationUtils.loadAnimation(this, R.anim.nazad1);
        animation1.setFillAfter(true);
        button.startAnimation(animation1);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(SecondActivity.this, MainActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.right,R.anim.left_in);
            }
        });
        AnimationDrawable Anim = (AnimationDrawable) imageView.getDrawable();
                Anim.start();
            }
        }
