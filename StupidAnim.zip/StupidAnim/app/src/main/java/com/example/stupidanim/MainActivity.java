package com.example.stupidanim;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {
    MaterialButton button;
    MaterialButton button1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
         findViewById(R.id.main);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = findViewById(R.id.kotiki);
        button1 = findViewById(R.id.pricol);
        Animation animRotateIn_icon = AnimationUtils.loadAnimation(this,
                R.anim.glavnknopki);

        button.startAnimation(animRotateIn_icon);
        button1.startAnimation(animRotateIn_icon);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(MainActivity.this, SecondActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.bottom, R.anim.top);
            }
        });

        button1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick (View v){
                    Intent intent = new Intent();
                    intent.setClass(MainActivity.this, Milota.class);
                    startActivity(intent);
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                }
        });

    }

}